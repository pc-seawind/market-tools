**MT14 真实首轮/续轮｜非投资验收**

{
  "run_id": "fixture-on-dd98ce24df4deb21",
  "engineering_status": "completed",
  "round_execution_status": "completed",
  "implementation_status": "completed",
  "strategy_decisions": [
    {
      "category": "fundamental",
      "candidate": "fundamental-e2ceac307e7d",
      "decision": "continue_shadow",
      "reason": "insufficient_mature_forward_samples",
      "independent_events": 0
    },
    {
      "category": "technical",
      "candidate": "technical-bf218f68ebfe",
      "decision": "continue_shadow",
      "reason": "insufficient_mature_forward_samples",
      "independent_events": 0
    }
  ],
  "candidate_count": 2,
  "fundamental_selected_counts": {
    "qv-shadow-1": 1,
    "fundamental-e2ceac307e7d": 0
  },
  "fundamental_scope_count": 1,
  "technical_scope_count": 9,
  "technical_actions": {
    "signal-policy-v1": {
      "001309.SZ": "HOLD",
      "603986.SH": "HOLD",
      "688195.SH": "HOLD",
      "301511.SZ": "HOLD",
      "300750.SZ": "HOLD",
      "601138.SH": "HOLD",
      "01810.HK": "HOLD",
      "03690.HK": "HOLD",
      "00700.HK": "HOLD"
    },
    "technical-bf218f68ebfe": {
      "001309.SZ": "HOLD",
      "603986.SH": "HOLD",
      "688195.SH": "HOLD",
      "301511.SZ": "HOLD",
      "300750.SZ": "HOLD",
      "601138.SH": "HOLD",
      "01810.HK": "HOLD",
      "03690.HK": "HOLD",
      "00700.HK": "HOLD"
    }
  },
  "kind": "REAL_CURRENT",
  "gaps": [],
  "scheduled": false,
  "next_check_at": "2026-09-13T22:10:49.388279+00:00",
  "production_activated": false,
  "no_efficacy_claim": true
}
