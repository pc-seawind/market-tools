**SYNTHETIC_ONLY｜不是行情/收益证据**
{
  "kind": "SYNTHETIC_ONLY",
  "scheduled": false,
  "engineering_status": "completed",
  "activation": {
    "category": "fundamental",
    "baseline": "qv-shadow-1",
    "candidate": "fundamental-e2ceac307e7d",
    "kind": "SYNTHETIC_ONLY",
    "contract_hash": "91a7057f880adbc54fdd72f01bd9305b03dd16caf5db35fb095f2d4cda1f1761",
    "asof": "2026-12-08T18:00:00+00:00",
    "independent_events": 20,
    "pairs": [
      {
        "code": "SYNTH-0",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "cc7a09239f4f3a2ca35bdc2786a1ac28442c48cd5c12252e677c92d16b1a8450"
      },
      {
        "code": "SYNTH-1",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "1018ad3c791be377bea4bc727df5c93e5c6798ebf25e22c22d3832d1db8a8795"
      },
      {
        "code": "SYNTH-10",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "0a28511992004cb044a2ea7e59f978eda0f927dcda2eb05d0f2e398690f5a56b"
      },
      {
        "code": "SYNTH-11",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "603d63b3889c7280ee274b058a5baf330b7453bd64084c22b286c6d937601e2d"
      },
      {
        "code": "SYNTH-12",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "3010cc7bb74fa7a646252da0fdced0637427861dd031842c58fa5bbcb36dac67"
      },
      {
        "code": "SYNTH-13",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "86abac06887fddc319d9f527cb659b7eefa37d40edbcf1c170da5b6166f65434"
      },
      {
        "code": "SYNTH-14",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "773cdb3fa122a37f81c355eddaef426ba71ef481822e719d2d3b3c6056eddb95"
      },
      {
        "code": "SYNTH-15",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "13e306d67b86920dfe7d12e4a6fd88a24fd8bb076a4b635a1086eb2937c96474"
      },
      {
        "code": "SYNTH-16",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "90d19e64feaa5add4ce04ae6e2355bbc4515c7a2292f263c2e955a297b3d4323"
      },
      {
        "code": "SYNTH-17",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "d814993ccc988a4b86b1b72e51e2499a6d56b2821420cc72ceef1806eb7eda92"
      },
      {
        "code": "SYNTH-18",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "fdaa8294288a1eb2bcb1ba20763cf00bb15c8a7ac0661f4b0ed4629de52ad650"
      },
      {
        "code": "SYNTH-19",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "7c96daaaa47adc529193e6576f2af1737c316d6ee2be73da235939e16b569b12"
      },
      {
        "code": "SYNTH-2",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "d4dc497420e0be4fad4b0494d00597fc35e4b449a9a049f0cc229b4bc6572e51"
      },
      {
        "code": "SYNTH-3",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "b39deaa1ad22018b69d07b911f9f88273f6189c2a962ae8479eac3cf10201a8c"
      },
      {
        "code": "SYNTH-4",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "2df3cb1ce214671aae408ff8c0275a5ac91873a04b400843edf1a12b01f77b6d"
      },
      {
        "code": "SYNTH-5",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "baba7f8ca072cdbb379836864dc50c8071cd84e671e4b57e8887f6ef6c21c235"
      },
      {
        "code": "SYNTH-6",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "4125880eee6dffde8562ec26559a55cb68daf8a885643bceded842897cc9dc29"
      },
      {
        "code": "SYNTH-7",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "ab37428a26c60ed19110110143d17b51ec882efe724858002ea856cc85302721"
      },
      {
        "code": "SYNTH-8",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "05184b1d56a67368d73cdaacec4b04df1fd0b056b3860e735e33f77c21f7ecdf"
      },
      {
        "code": "SYNTH-9",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": -0.303599876567059,
          "drawdown": -0.303599876567059,
          "tail": -0.0071428571428571175,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "5145c546e3ad13b43284c955706c4a5cdc36b6d744708b3ac9af505e58324e66"
      }
    ],
    "pending": [],
    "horizon_counts_diagnostic": {
      "20": 20,
      "40": 20,
      "60": 20
    },
    "decision": "experimental_activate",
    "reason": "matched_signal_forward_improvement_not_production_validation",
    "metric_type": "matched_forward_signal_cash_slots_not_fill_or_personal_PnL",
    "execution_evidence_is_separate": true,
    "input_hash": "c36b1eb586b021860499e92092db15bfbd9039a733de018316f3c871e67118d3",
    "baseline_metrics": {
      "net": -0.303599876567059,
      "drawdown": -0.303599876567059,
      "tail": -0.0071428571428571175,
      "turnover": 2.0
    },
    "candidate_metrics": {
      "net": 0.0,
      "drawdown": 0.0,
      "tail": 0.0,
      "turnover": 0.0
    },
    "idempotent": true,
    "pointer": "/home/emox/work/projects/market-tools/reports/mt14-20260913/synthetic-complete/releases/fundamental/active.json"
  },
  "rejection": {
    "category": "fundamental",
    "baseline": "qv-shadow-1",
    "candidate": "fundamental-e2ceac307e7d",
    "kind": "SYNTHETIC_ONLY",
    "contract_hash": "91a7057f880adbc54fdd72f01bd9305b03dd16caf5db35fb095f2d4cda1f1761",
    "asof": "2026-12-08T18:00:00+00:00",
    "independent_events": 20,
    "pairs": [
      {
        "code": "SYNTH-0",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "0808de3e2242a864c165a512b1aa23a7668f0591709c4c2f7cd704126f41750b"
      },
      {
        "code": "SYNTH-1",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "7ef04b02bb31a96957d3bbc09fc33403bfab364756ebc9a850de55cb6711759f"
      },
      {
        "code": "SYNTH-10",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "65f364c4328021d33457103a49c075160e06a2d86132a956372aed1c28bdf552"
      },
      {
        "code": "SYNTH-11",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "fc3bd0099d348628dcfe3f4130580757564d1f9deedcac1bba67a9999055760d"
      },
      {
        "code": "SYNTH-12",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "bc00e7eca9c7979f85c9c1c21c4710c9229b1cf089b2c5d78014696c2b551062"
      },
      {
        "code": "SYNTH-13",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "ddd912723bf26070abfd5295cdf148b9daefe2b39b4bfae140f0a5a5fbce84b6"
      },
      {
        "code": "SYNTH-14",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "af364945b4f697e357a44a9fdb97fb28828364e412f4cb1fb2c4b6c53a966082"
      },
      {
        "code": "SYNTH-15",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "174091a33b86eabdf65c5c02ca2a776021d683cfb64d67dcb0add8cfe5c93814"
      },
      {
        "code": "SYNTH-16",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "7ffe8073a4a2104ec16018a2600eac69461734522fd90ab0a07ff6abe7c5f8a5"
      },
      {
        "code": "SYNTH-17",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "0626cb3bdb59213ae95c915ba223beb669d34efc2160fc76aced73c936b28fef"
      },
      {
        "code": "SYNTH-18",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "2cda23a7a90a0eb75150bafc70b68105a2b46f32c08e27f3bb4e3d07e881321d"
      },
      {
        "code": "SYNTH-19",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "3bf549a6586edf930509f88a5a8b0efb3b00e4207f054e3415c93b3a41cb6cd6"
      },
      {
        "code": "SYNTH-2",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "ded5031571399e8887a7dda0410e1d3b0f21eb1baf2eacfd1a2d7f0293bab1aa"
      },
      {
        "code": "SYNTH-3",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "981dd231403eabf0c68b96d0781e237c67c253ce41097f0e7d4be4a456491f14"
      },
      {
        "code": "SYNTH-4",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "1dca41e3355438c773ab1fce98cea8700d5cc5040b6cf2e7bb3582f5db647f2e"
      },
      {
        "code": "SYNTH-5",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "4c179f27391b906534f385fe752b24960509e5c97003bad88e4a3ef27ff59002"
      },
      {
        "code": "SYNTH-6",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "30994ee1c85ce251e4e070b5cd3f373d4d0199d7a91cbeb8f8e027fe6a9d191b"
      },
      {
        "code": "SYNTH-7",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "53b0963f888f065e458929b9617cdfe43a38bd652c120c2e3c743413c2cdac60"
      },
      {
        "code": "SYNTH-8",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "d82f30c4e8c896db6d5421c88bf237af833a6c3930fb48e7a4c72ad953f2cf50"
      },
      {
        "code": "SYNTH-9",
        "scope_hash": "936e4c77da2d4212adc0870561dc14473f75d8d5f4de936914d835d8ae4507a6",
        "origin": "2026-09-14",
        "start": "2026-09-15",
        "end": "2026-12-08",
        "baseline": {
          "net": 0.29461777483029183,
          "drawdown": -0.0014977533699450651,
          "tail": 0.0038461538461538325,
          "turnover": 2.0
        },
        "candidate": {
          "net": 0.0,
          "drawdown": 0.0,
          "tail": 0.0,
          "turnover": 0.0
        },
        "evidence_hash": "fcc0de699d75b667e0e5f66160f87573840dbaf578c4bf6dc470a4fe970c9316"
      }
    ],
    "pending": [],
    "horizon_counts_diagnostic": {
      "20": 20,
      "40": 20,
      "60": 20
    },
    "decision": "reject",
    "reason": "no_improvement_or_risk_worse",
    "metric_type": "matched_forward_signal_cash_slots_not_fill_or_personal_PnL",
    "execution_evidence_is_separate": true,
    "input_hash": "45f6c52cf6ef216ac8f70e7142a6904c77d41e93a482164806c3ee6f2dad64c7",
    "baseline_metrics": {
      "net": 0.29461777483029183,
      "drawdown": -0.0014977533699450651,
      "tail": 0.0038461538461538325,
      "turnover": 2.0
    },
    "candidate_metrics": {
      "net": 0.0,
      "drawdown": 0.0,
      "tail": 0.0,
      "turnover": 0.0
    }
  },
  "immature": {
    "category": "fundamental",
    "baseline": "qv-shadow-1",
    "candidate": "fundamental-e2ceac307e7d",
    "kind": "SYNTHETIC_ONLY",
    "contract_hash": "91a7057f880adbc54fdd72f01bd9305b03dd16caf5db35fb095f2d4cda1f1761",
    "asof": "2026-12-08T18:00:00+00:00",
    "independent_events": 0,
    "pairs": [],
    "pending": [
      {
        "code": "SYNTH-0",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-0",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-0",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-0",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-0",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-0",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-0",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-0",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-0",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-0",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-1",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-1",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-1",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-1",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-1",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-1",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-1",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-1",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-1",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-1",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-10",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-10",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-10",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-10",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-10",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-10",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-10",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-10",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-10",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-10",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-11",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-11",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-11",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-11",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-11",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-11",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-11",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-11",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-11",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-11",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-12",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-12",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-12",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-12",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-12",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-12",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-12",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-12",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-12",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-12",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-13",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-13",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-13",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-13",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-13",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-13",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-13",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-13",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-13",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-13",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-14",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-14",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-14",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-14",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-14",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-14",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-14",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-14",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-14",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-14",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-15",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-15",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-15",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-15",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-15",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-15",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-15",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-15",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-15",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-15",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-16",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-16",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-16",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-16",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-16",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-16",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-16",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-16",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-16",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-16",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-17",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-17",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-17",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-17",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-17",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-17",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-17",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-17",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-17",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-17",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-18",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-18",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-18",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-18",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-18",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-18",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-18",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-18",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-18",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-18",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-19",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-19",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-19",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-19",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-19",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-19",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-19",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-19",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-19",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-19",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-2",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-2",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-2",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-2",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-2",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-2",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-2",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-2",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-2",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-2",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-3",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-3",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-3",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-3",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-3",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-3",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-3",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-3",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-3",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-3",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-4",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-4",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-4",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-4",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-4",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-4",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-4",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-4",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-4",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-4",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-5",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-5",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-5",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-5",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-5",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-5",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-5",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-5",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-5",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-5",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-6",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-6",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-6",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-6",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-6",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-6",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-6",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-6",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-6",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-6",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-7",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-7",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-7",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-7",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-7",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-7",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-7",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-7",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-7",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-7",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-8",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-8",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-8",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-8",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-8",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-8",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-8",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-8",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-8",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-8",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-9",
        "origin": "2026-09-14",
        "observed_sessions": 9,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-9",
        "origin": "2026-09-15",
        "observed_sessions": 8,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-9",
        "origin": "2026-09-16",
        "observed_sessions": 7,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-9",
        "origin": "2026-09-17",
        "observed_sessions": 6,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-9",
        "origin": "2026-09-18",
        "observed_sessions": 5,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-9",
        "origin": "2026-09-21",
        "observed_sessions": 4,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-9",
        "origin": "2026-09-22",
        "observed_sessions": 3,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-9",
        "origin": "2026-09-23",
        "observed_sessions": 2,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-9",
        "origin": "2026-09-24",
        "observed_sessions": 1,
        "reason": "not_matured",
        "required": 61
      },
      {
        "code": "SYNTH-9",
        "origin": "2026-09-25",
        "observed_sessions": 0,
        "reason": "not_matured",
        "required": 61
      }
    ],
    "horizon_counts_diagnostic": {
      "20": 0,
      "40": 0,
      "60": 0
    },
    "decision": "continue_shadow",
    "reason": "insufficient_mature_forward_samples",
    "metric_type": "matched_forward_signal_cash_slots_not_fill_or_personal_PnL",
    "execution_evidence_is_separate": true,
    "input_hash": "e8d758148cf3a2961b7c828c951a82d86616a4b1a7d6274570ea89b6864bbc35"
  },
  "recovery": [
    {
      "category": "fundamental",
      "action": "resume_prepared"
    }
  ],
  "tamper_rollback": [
    {
      "category": "fundamental",
      "action": "automatic_rollback",
      "from": "fundamental-e2ceac307e7d",
      "to": "qv-shadow-1",
      "reason": "active_evidence_tampered",
      "retained_ledgers": true
    }
  ],
  "pointer_before": {
    "version": "fundamental-e2ceac307e7d",
    "baseline_version": "qv-shadow-1",
    "category": "fundamental",
    "kind": "SYNTHETIC_ONLY",
    "evidence_path": "/home/emox/work/projects/market-tools/reports/mt14-20260913/synthetic-complete/forward.json",
    "evidence_hash": "b09bb3a7ee866a7195bacf132df7e341259a1d4a5bd376f84cfe83cd3a57a0af",
    "evaluation_hash": "5c71d549c1462790507b81a986ac3b0b49afdec48de34dafa2dcd4f98dc43749",
    "asof": "2026-12-08T18:00:00+00:00",
    "previous": {
      "version": "qv-shadow-1",
      "baseline": true
    },
    "production": false
  },
  "pointer_after": {
    "version": "qv-shadow-1",
    "baseline": true
  },
  "execution_roundtrip": {
    "SYNTHETIC_ONLY": true,
    "actions": [
      "WAIT",
      "BUY",
      "HOLD",
      "SELL",
      "WAIT"
    ],
    "receipts": [
      {
        "manifest": "/home/emox/work/projects/market-tools/reports/mt14-20260913/synthetic-complete/execution-roundtrip/archive/mt13-action/SYNTHETIC-epoch/2026-09-14/170ef7ce6c4d3d0b055b062e/r000001/manifest.json",
        "revision": 1,
        "sha256": "86ba20906bde4ee44c0ad3f3ae556ca057a01edbfc3827882595117c8f250f2d"
      },
      {
        "manifest": "/home/emox/work/projects/market-tools/reports/mt14-20260913/synthetic-complete/execution-roundtrip/archive/mt13-action/SYNTHETIC-epoch/2026-09-15/e08a138bc95d2cfd2f4c4994/r000001/manifest.json",
        "revision": 1,
        "sha256": "439ef8129a9500835e874947c81cc6d669fc5daa454012ba910e69e1d9675259"
      },
      {
        "manifest": "/home/emox/work/projects/market-tools/reports/mt14-20260913/synthetic-complete/execution-roundtrip/archive/mt13-action/SYNTHETIC-epoch/2026-09-16/d49d3b85b141ed987a7a4c18/r000001/manifest.json",
        "revision": 1,
        "sha256": "b2411ad83f4fa70be449421fef05e1c75c2b89219fb9e71a424eff283ee186bb"
      },
      {
        "manifest": "/home/emox/work/projects/market-tools/reports/mt14-20260913/synthetic-complete/execution-roundtrip/archive/mt13-action/SYNTHETIC-epoch/2026-09-17/8cd63253edc4d11d1e93086e/r000001/manifest.json",
        "revision": 1,
        "sha256": "03fa3ee875d60b73206bb853c3097e7854148e76f715ab021c6e88d76d45c514"
      },
      {
        "manifest": "/home/emox/work/projects/market-tools/reports/mt14-20260913/synthetic-complete/execution-roundtrip/archive/mt13-action/SYNTHETIC-epoch/2026-09-18/510731b8e0cc40d2cc311898/r000001/manifest.json",
        "revision": 1,
        "sha256": "f2fa15b159d632985f896e3bab9a5e72ee3b25a5e1bc8734586cc56f5a1a9c50"
      }
    ],
    "round_trips": 1,
    "fills": [
      {
        "date": "2026-09-16",
        "at": "2026-09-16T09:30:00+08:00",
        "raw_price": 108.5,
        "adjusted_price": 108.5,
        "source_sha256": "0103b1f8b8634db26bd776923b96e667e53f66c4072400778902e2169ed642e7",
        "snapshot_sha256": "52d653f18f2afef72144b0e85730beac48a94ea6ececbb0c2669cac6a4a4ec78",
        "virtual_units": 1,
        "not_real_trade": true,
        "cost_bps_scenario": 15.0,
        "provider_at": null,
        "execution_assumption": "strict next-open simulation with supplied evidence; not a real trade",
        "execution_model": "strict-open-v1",
        "attempt_number": 1
      },
      {
        "date": "2026-09-18",
        "at": "2026-09-18T09:30:00+08:00",
        "raw_price": 79,
        "adjusted_price": 79.0,
        "source_sha256": "c6ee316a21c6f4b80043884eb50b56e2af5a31e5b82f4656621a190008b37fa8",
        "snapshot_sha256": "7bcefdb541fff9da54b7a17012b69ed6d74bc811c1477f776b9f2a7415115967",
        "virtual_units": 1,
        "not_real_trade": true,
        "cost_bps_scenario": 15.0,
        "provider_at": null,
        "execution_assumption": "strict next-open simulation with supplied evidence; not a real trade",
        "execution_model": "strict-open-v1",
        "attempt_number": 1
      }
    ],
    "weekly": "/home/emox/work/projects/market-tools/reports/mt14-20260913/synthetic-complete/execution-roundtrip/weekly.json",
    "not_real_trade_or_efficacy": true
  },
  "paired_technical_versions": [
    "signal-policy-v1",
    "technical-bf218f68ebfe"
  ],
  "real_sample_count": 0,
  "no_efficacy_claim": true
}